// Main JavaScript for Password Management System

document.addEventListener('DOMContentLoaded', function() {
    // Handle the refresh button
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', refreshData);
    }
    
    // Handle the reset form
    const resetForm = document.getElementById('resetForm');
    if (resetForm) {
        resetForm.addEventListener('submit', resetPassword);
    }
    
    // Handle vendor selection for password reset
    const vendorSelect = document.getElementById('vendorSelect');
    if (vendorSelect) {
        vendorSelect.addEventListener('change', updateResetForm);
    }
});

// Function to refresh data from the Google Sheet
function refreshData() {
    fetch('/api/refresh-sheet', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Show success message
            showAlert('Dados atualizados com sucesso!', 'success');
            // Reload the page to show updated stats
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showAlert('Erro ao atualizar os dados: ' + (data.error || 'Erro desconhecido'), 'danger');
        }
    })
    .catch(error => {
        showAlert('Erro ao atualizar os dados: ' + error, 'danger');
    });
}

// Function to reset a password
function resetPassword(event) {
    event.preventDefault();
    
    const vendorSelect = document.getElementById('vendorSelect');
    const passwordInput = document.getElementById('passwordInput');
    
    if (!vendorSelect.value) {
        showAlert('Selecione um vendedor para resetar a senha', 'warning');
        return;
    }
    
    // Get the selected option
    const selectedOption = vendorSelect.options[vendorSelect.selectedIndex];
    const isUsed = selectedOption.getAttribute('data-used') === 'true';
    
    // Only proceed if the password is marked as used
    if (!isUsed) {
        showAlert('Esta senha já está marcada como não utilizada', 'info');
        return;
    }
    
    fetch('/api/reset-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            vendor: vendorSelect.value,
            password: passwordInput.value || '' // If no password is provided, send empty string
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showAlert('Senha resetada com sucesso!', 'success');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showAlert('Erro ao resetar senha: ' + (data.error || 'Erro desconhecido'), 'danger');
        }
    })
    .catch(error => {
        showAlert('Erro ao resetar senha: ' + error, 'danger');
    });
}

// Function to update the reset form based on vendor selection
function updateResetForm() {
    const vendorSelect = document.getElementById('vendorSelect');
    const resetButton = document.querySelector('#resetForm button[type="submit"]');
    
    if (!vendorSelect.value) {
        resetButton.disabled = true;
        return;
    }
    
    // Get the selected option
    const selectedOption = vendorSelect.options[vendorSelect.selectedIndex];
    const isUsed = selectedOption.getAttribute('data-used') === 'true';
    
    // Enable/disable the reset button based on whether the password is marked as used
    resetButton.disabled = !isUsed;
    
    if (!isUsed) {
        showAlert('Esta senha já está marcada como não utilizada', 'info');
    }
}

// Function to show alerts
function showAlert(message, type = 'info') {
    // Create alert element
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.role = 'alert';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Insert at the top of the container
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const bsAlert = new bootstrap.Alert(alertDiv);
        bsAlert.close();
    }, 5000);
}
